Uploading Photos with HTML5
=========
Take a photo from mobile devices (Android, iOS and so on) with HTML5, and upload the image to remote servers. 

Blog
-----------

[Take a Photo and Upload it on Mobile Phones with HTML5][1]

[1]:http://www.codepool.biz/tech-frontier/html5/take-a-photo-and-upload-it-on-mobile-phones-with-html5.html
